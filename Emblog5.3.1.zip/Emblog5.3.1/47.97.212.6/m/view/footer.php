<div id="footer">powered by <a href="http://www.emlog.net/">emlog</a></div>
</body>
</html>